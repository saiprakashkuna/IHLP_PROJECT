package com.p2p.project.Helpers;

public class Constants {
    public final static String URL = "http://localhost:8080";
    public final static String SETTING_FILE_NAME = "setting.json";
}
