package com.p2p.project.ServerClient;

import com.p2p.project.Helpers.SettingHelper;
import com.p2p.project.models.Setting;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server extends Thread {
    private ServerSocket serverSocket;

    @Override
    public void run() {
        try {
            Setting setting = SettingHelper.getSetting();
            int port = setting.getPort();
            serverSocket = new ServerSocket(port);
            
            // Add shutdown hook to close the server socket
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    serverSocket.close();
                    System.out.println("Server socket closed.");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }));

            while (!serverSocket.isClosed()) {
                Socket socket = serverSocket.accept();
                System.out.println("connected..");
                Thread t = new Thread(() -> {
                    try (DataInputStream in = new DataInputStream(socket.getInputStream());
                         DataOutputStream out = new DataOutputStream(socket.getOutputStream())) {
                        String filename = in.readUTF();
                        String filepath = setting.getUploadPath() + File.separator + filename;
                        readFile(filepath, out);
                        socket.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                t.start();
            }

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (serverSocket != null && !serverSocket.isClosed()) {
                try {
                    serverSocket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void readFile(String path, DataOutputStream out) {
        File file = new File(path);
        try (FileInputStream in = new FileInputStream(file)) { // try-with-resources to auto-close
            int c;
            while ((c = in.read()) != -1) {
                out.write(c);
                out.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
