package com.p2p.project.views;

import com.p2p.project.Helpers.HelperFunctions;
import com.p2p.project.Helpers.SettingHelper;
import com.p2p.project.ServerClient.Server;
import com.p2p.project.models.Setting;

import javax.swing.*;
import java.io.File;

public class FileTransferLogin extends JFrame {
    private static final long serialVersionUID = -3107058284882699789L;
    
	private JTextField textUploadDirectory;
    private JButton uploadChooseButton;
    private JTextField textDownloadDirectory;
    private JButton downloadChooseButton;
    private JPanel rootPanel;
    private JButton doneButton;
    private JTextField textAddress;
    private JTextField textPort;
    private JTextField textUserName;


    public FileTransferLogin() {
        rootPanel = new JPanel(null); // using null layout
        initComponents();
        setContentPane(rootPanel);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(650, 400);
        setLocationRelativeTo(null);
        setVisible(true);
    }
	    private void chooseDirectory(JTextField textField) {
	        JFileChooser fileChooser = new JFileChooser();
	        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	        int option = fileChooser.showOpenDialog(this);
	        if (option == JFileChooser.APPROVE_OPTION) {
	            File selectedDirectory = fileChooser.getSelectedFile();
	            textField.setText(selectedDirectory.getAbsolutePath());
	        }
	    }

        private void initComponents() {
            textUploadDirectory = new JTextField();
            textUploadDirectory.setBounds(50, 20, 150, 25);
            rootPanel.add(textUploadDirectory);

            uploadChooseButton = new JButton("Choose Upload Directory");
            uploadChooseButton.setBounds(210, 20, 220, 25);
            uploadChooseButton.addActionListener(e -> chooseDirectory(textUploadDirectory));
            rootPanel.add(uploadChooseButton);

            textDownloadDirectory = new JTextField();
            textDownloadDirectory.setBounds(50, 60, 150, 25);
            rootPanel.add(textDownloadDirectory);

            downloadChooseButton = new JButton("Choose Download Directory");
            downloadChooseButton.setBounds(210, 60, 220, 25);
            downloadChooseButton.addActionListener(e -> chooseDirectory(textDownloadDirectory));
            rootPanel.add(downloadChooseButton);

            textAddress = new JTextField();
            textAddress.setBounds(50, 100, 150, 25);
            rootPanel.add(textAddress);

            textPort = new JTextField();
            textPort.setBounds(210, 100, 150, 25);
            rootPanel.add(textPort);

            textUserName = new JTextField();
            textUserName.setBounds(370, 100, 150, 25);
            rootPanel.add(textUserName);

            doneButton = new JButton("Done");
            doneButton.setBounds(210, 140, 80, 25);
            doneButton.addActionListener(e -> login());
            rootPanel.add(doneButton);
    }
    private void  login(){
        try{
            final String uploadDirectory = textUploadDirectory.getText();
            final String downloadDirectory = textDownloadDirectory.getText();
            final String address = textAddress.getText();
            final int port =  Integer.parseInt(textPort.getText());
            final String username = textUserName.getText();
            Thread t = new Thread(()->{
                if(!uploadDirectory.isEmpty() && !downloadDirectory.isEmpty()){
                    Setting setting = SettingHelper.getSetting();
                    if(setting != null){
                        String id = setting.getId();
                        HelperFunctions.uploadPeerInformation(uploadDirectory,address, port, username, id);
                        setting.setUsername(username);
                        setting.setUploadPath(uploadDirectory);
                        setting.setDownloadPath(downloadDirectory);
                        setting.setAddress(address);
                        setting.setPort(port);
                    }else{
                        String id = HelperFunctions.uploadPeerInformation(uploadDirectory,address, port, username,null);
                        setting = new Setting(downloadDirectory,uploadDirectory,address,port,username,id);
                    }
                    SettingHelper.saveSetting(setting);
                    setVisible(false);
                    new FileTransferScreen();
                    Server server = new Server();
                    server.start();

                }
            });
            t.start();

        }catch(Exception exp){

        }

    }

    private File selectFolder(){
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int option = fileChooser.showOpenDialog(this);
        if(option == JFileChooser.APPROVE_OPTION){
            File file = fileChooser.getSelectedFile();
            return file;
        }else{
            return null;
        }
    }

    private void loadSetting(){
        Thread t = new Thread(()->{
            Setting setting = SettingHelper.getSetting();
            if(setting!=null){
                textDownloadDirectory.setText(setting.getDownloadPath());
                textUploadDirectory.setText(setting.getUploadPath());
                textUserName.setText(setting.getUsername());
                textAddress.setText(setting.getAddress());
                textPort.setText(setting.getPort() + "");
            }
        });
        t.start();
    }
}
