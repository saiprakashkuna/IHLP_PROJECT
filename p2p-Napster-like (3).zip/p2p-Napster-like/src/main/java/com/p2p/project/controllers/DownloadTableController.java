package com.p2p.project.controllers;

import com.p2p.project.Helpers.HelperFunctions;
import com.p2p.project.Helpers.SettingHelper;
import com.p2p.project.models.Download;
import com.p2p.project.models.Setting;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class DownloadTableController {
    private JTable downloadTable;
    private List<Download> downloadTableFiles = new ArrayList<>();
    private DefaultTableModel downloadTableModel;
    private final JMenuItem deleteItem = new JMenuItem("delete");
    private final JMenuItem openFileLocation = new JMenuItem("open file");

    public DownloadTableController(JTable downloadTable) {
        this.downloadTable = downloadTable;
        defineTable();
        Thread t = new Thread(this::loadDownloads);
        t.start();
    }

    private void defineTable() {
        downloadTableModel = new DefaultTableModel() {
            private static final long serialVersionUID = 1L;  // serialVersionUID added here

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        downloadTable.setModel(downloadTableModel);
        downloadTableModel.addColumn("File Name");
        downloadTableModel.addColumn("File Size");
        downloadTableModel.addColumn("File Type");
        downloadTableModel.addColumn("Date");

        JPopupMenu rowOptions = new JPopupMenu();
        rowOptions.add(deleteItem);
        rowOptions.add(openFileLocation);

        deleteItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                final int selectedRow = downloadTable.getSelectedRow();
                deleteRow(selectedRow);
            }
        });

        openFileLocation.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                final int selectedRow = downloadTable.getSelectedRow();
                openFileLocation(selectedRow);
            }
        });

        downloadTable.setComponentPopupMenu(rowOptions);
    }

    private void deleteRow(final int selectedRow) {
        final String filename = downloadTableFiles.get(selectedRow).getFilename();
        downloadTableModel.removeRow(selectedRow);
        SettingHelper.deleteDownload(filename);
        HelperFunctions.deleteFile(filename);
    }

    private void openFileLocation(final int selectedRow) {
        final String filename = downloadTableFiles.get(selectedRow).getFilename();
        Setting setting = SettingHelper.getSetting();
        final String filePath = setting.getDownloadPath() + File.separator + filename;

        Thread t = new Thread(() -> {
            try {
                Desktop.getDesktop().open(new File(filePath));
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        t.start();
    }

    public void loadDownloads() {
        downloadTableModel.setRowCount(0);
        final Setting setting = SettingHelper.getSetting();
        if (setting != null) {
            downloadTableFiles = setting.getDownloads();
            for (Download download : downloadTableFiles) {
                SwingUtilities.invokeLater(() -> downloadTableModel.addRow(new Object[]{
                        download.getFilename(),
                        download.getFilesize(),
                        download.getFileType(),
                        download.getDownloadDate()
                }));
            }
        }
    }
}
