package com.p2p.project;
import com.p2p.project.views.FileTransferLogin;
import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new FileTransferLogin();
        });
    }
}

