const express = require("express");
const { v4: uuidv4 } = require('uuid');
const app = express();

// Demo data for store
const store = [
  {
    id: uuidv4(),
    owner: "john",
    address: "localhost:8081",
    port: 8081,
    files: [
      {
        filename: "a_8081.txt",
        filetype: "audio",
        filesize: "30 mb",
      },
      {
        filename: "b_8081.txt",
        filetype: "video",
        filesize: "15 mb",
      },
    ],
  },
  {
    id: uuidv4(),
    owner: "jane",
    address: "localhost:8082",
    port: 8082,
    files: [
      {
        filename: "a_8082.txt",
        filetype: "audio",
        filesize: "30 mb",
      },
      {
        filename: "b_8082.txt",
        filetype: "video",
        filesize: "15 mb",
      },
    ],
  },
  {
    id: uuidv4(),
    owner: "abebe",
    address: "localhost:8083",
    port: 8083,
    files: [
      {
        filename: "a_8083.txt",
        filetype: "audio",
        filesize: "30 mb",
      },
      {
        filename: "b_8083.txt",
        filetype: "video",
        filesize: "15 mb",
      },
    ],
  },
];

app.use(express.json());

app.get("/", (req, res) => {
  try {
    const keyword = req.query.keyword || "";
    const filterId = req.query.filterId || "";
    const searchedList = searchLists(store, keyword, filterId);
    return res.json(searchedList);
  } catch (error) {
    console.error(error);
    res.status(500).send("An error occurred");
  }
});

app.post("/", (req, res) => {
  try {
    const reqBody = req.body;
    reqBody.id = reqBody.id === undefined ? uuidv4() : reqBody.id;
    const existingIndex = store.findIndex(item => item.id === reqBody.id);
    if (existingIndex !== -1) {
      store[existingIndex] = reqBody;
    } else {
      store.push(reqBody);
    }
    return res.status(200).send(reqBody.id);
  } catch (error) {
    console.error(error);
    res.status(500).send("An error occurred");
  }
});

const port = process.argv[2] || 8080;
app.listen(port, () => console.log(`Server is listening on port ${port}`));

function searchLists(datas, keyword, filterId) {
  return datas.filter(data => data.id !== filterId).map(data => {
    const files = data.files.filter(file => file.filename.toLowerCase().includes(keyword.toLowerCase()));
    return {
      ...data,
      files,
    };
  }).filter(data => data.files.length > 0);
}

module.exports = app; 
